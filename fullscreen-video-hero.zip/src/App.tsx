/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { Menu, X, Volume2, VolumeX, Play, Pause, ArrowRight, Compass, Sparkles, Check } from 'lucide-react';

export default function App() {
  const [activeLink, setActiveLink] = useState('Home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(true);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [saturation, setSaturation] = useState(100);
  const [brightness, setBrightness] = useState(100);
  
  const videoRef = useRef<HTMLVideoElement>(null);

  // Sync state with video properties
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isVideoMuted;
    }
  }, [isVideoMuted]);

  useEffect(() => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.play().catch(() => {
          setIsVideoPlaying(false);
        });
      } else {
        videoRef.current.pause();
      }
    }
  }, [isVideoPlaying]);

  const toggleMute = () => {
    setIsVideoMuted(prev => !prev);
    triggerToast(isVideoMuted ? "Sound enabled. Feel the atmosphere." : "Sound muted.");
  };

  const togglePlay = () => {
    setIsVideoPlaying(prev => !prev);
    triggerToast(isVideoPlaying ? "Video paused." : "Video playing.");
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
  };

  // Automatically dismiss toast
  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const navLinks = ['Home', 'Studio', 'About', 'Journal', 'Reach Us'];

  const handleLinkClick = (link: string) => {
    setActiveLink(link);
    setIsMobileMenuOpen(false);
    triggerToast(`Welcome to the ${link} section of Velorah.`);
  };

  return (
    <div id="velorah-app" className="relative w-screen min-h-screen select-none overflow-x-hidden bg-background text-foreground flex flex-col justify-between">
      {/* Background Video */}
      <video
        ref={videoRef}
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260314_131748_f2ca2a28-fed7-44c8-b9a9-bd9acdd5ec31.mp4"
        autoPlay
        loop
        muted={isVideoMuted}
        playsInline
        className={`absolute inset-0 w-full h-full object-cover z-0 pointer-events-none transition-all duration-1000 ease-out ${
          isVideoPlaying ? 'opacity-40 scale-100' : 'opacity-15 scale-[1.02] blur-[2px]'
        }`}
        style={{ filter: `saturate(${saturation}%) brightness(${brightness}%)` }}
      />

      {/* Cinematic Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[rgba(0,18,34,0.4)] via-transparent to-[rgba(0,18,34,0.8)] z-0 pointer-events-none"></div>

      {/* Top Navigation */}
      <header id="nav-header" className="relative z-10 w-full">
        <nav className="flex flex-row justify-between items-center px-10 py-8 max-w-[1024px] mx-auto w-full">
          {/* Logo */}
          <div 
            id="brand-logo" 
            className="text-3xl tracking-tight text-foreground cursor-pointer transition-transform duration-300 hover:scale-[1.01]"
            style={{ fontFamily: "var(--font-display)" }}
            onClick={() => handleLinkClick('Home')}
          >
            Velorah<sup className="text-[10px] ml-0.5 font-sans font-light">®</sup>
          </div>

          {/* Desktop Links */}
          <div id="desktop-links" className="hidden md:flex flex-row items-center gap-8 ml-auto mr-12 text-muted-foreground">
            {navLinks.map((link) => (
              <button
                key={link}
                id={`nav-${link.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => handleLinkClick(link)}
                className={`text-sm tracking-wide transition-colors duration-300 nav-link cursor-pointer ${
                  activeLink === link 
                    ? 'text-foreground font-medium' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {link}
              </button>
            ))}
          </div>

          {/* Nav Right CTA Button & Mobile Menu Toggle */}
          <div id="nav-actions" className="flex items-center gap-4">
            <button
              id="cta-nav-journey"
              onClick={() => triggerToast("Initiating your custom journey experience...")}
              className="liquid-glass rounded-full px-6 py-2.5 text-sm font-medium text-foreground transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] cursor-pointer hidden sm:block shadow-sm btn-nav"
            >
              Begin Journey
            </button>

            {/* Mobile burger toggle */}
            <button
              id="mobile-menu-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden flex items-center justify-center p-2 rounded-full cursor-pointer transition-colors duration-200 hover:bg-white/5 active:bg-white/10 text-foreground"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </nav>

        {/* Mobile menu overlay */}
        {isMobileMenuOpen && (
          <div 
            id="mobile-menu-overlay" 
            className="md:hidden absolute top-full left-4 right-4 mt-2 liquid-glass rounded-2xl p-6 flex flex-col gap-5 z-20 shadow-2xl animate-fade-rise"
          >
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link}
                  id={`mobile-nav-${link.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => handleLinkClick(link)}
                  className={`text-left py-2 text-base tracking-wide transition-all ${
                    activeLink === link 
                      ? 'text-foreground font-medium pl-2 border-l border-white/50' 
                      : 'text-muted-foreground pl-0 hover:pl-2'
                  }`}
                >
                  {link}
                </button>
              ))}
            </div>
            
            <div className="border-t border-white/10 pt-4 mt-2">
              <button
                id="mobile-cta-journey"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  triggerToast("Initiating your custom journey experience...");
                }}
                className="w-full liquid-glass rounded-full py-3 text-center text-sm font-medium text-foreground transition-all duration-200 hover:bg-white/5 btn-nav"
              >
                Begin Journey
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <main id="hero-main" className="relative z-10 flex-grow flex items-center justify-center w-full max-w-[1024px] mx-auto -mt-12">
        <div className="flex flex-col items-center text-center px-16 w-full justify-center">
          {/* Animated Cinematic Title */}
          <h1
            id="hero-tagline"
            className="hero-title max-w-[900px] mb-8 text-foreground animate-fade-rise"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Where <span className="text-muted-foreground italic font-normal">dreams</span> rise <span className="text-muted-foreground font-normal">through the silence.</span>
          </h1>

          {/* Animated Subtext */}
          <p
            id="hero-description"
            className="text-muted-foreground text-lg max-w-[620px] leading-relaxed mb-12 font-sans animate-fade-rise-delay"
          >
            We're designing tools for deep thinkers, bold creators, and quiet rebels. Amid the chaos, we build digital spaces for sharp focus and inspired work.
          </p>

          {/* Animated Hero Button */}
          <div className="animate-fade-rise-delay-2">
            <button
              id="cta-hero-journey"
              onClick={() => triggerToast("Exploring path of quiet dreams...")}
              className="liquid-glass rounded-full px-14 py-5 text-base font-medium text-foreground transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] cursor-pointer shadow-lg tracking-wide group btn-main"
            >
              <span className="flex items-center gap-2 justify-center">
                Begin Journey
                <ArrowRight size={16} className="text-muted-foreground group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
          </div>
        </div>
      </main>

      {/* Footer & Atmospheric Controls */}
      <footer id="cinematic-footer" className="relative z-10 w-full border-t border-white/5 bg-gradient-to-t from-black/20 to-transparent">
        <div className="max-w-[1024px] mx-auto px-10 py-6 flex flex-col lg:flex-row justify-between items-center gap-6 text-[10px] uppercase tracking-widest text-muted-foreground transition-all duration-300 w-full opacity-60 hover:opacity-100">
          <span>Est. 2024 — Digital Crafts</span>

          {/* Controls Cluster */}
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Cinematic player state controls */}
            <div id="video-controls" className="flex items-center gap-4 h-full md:border-r md:border-white/10 md:pr-6">
              <button
                id="control-play-pause"
                onClick={togglePlay}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full hover:bg-white/5 active:bg-white/10 text-muted-foreground hover:text-foreground transition-all cursor-pointer"
                title={isVideoPlaying ? "Pause ambient video" : "Play ambient video"}
              >
                {isVideoPlaying ? <Pause size={10} /> : <Play size={10} />}
                <span>{isVideoPlaying ? "PAUSE AMBIENT" : "PLAY AMBIENT"}</span>
              </button>
              
              <button
                id="control-mute"
                onClick={toggleMute}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full hover:bg-white/5 active:bg-white/10 text-muted-foreground hover:text-foreground transition-all cursor-pointer"
                title={isVideoMuted ? "Unmute atmospheric background" : "Mute background audio"}
              >
                {isVideoMuted ? <VolumeX size={10} /> : <Volume2 size={10} />}
                <span>{isVideoMuted ? "SOUND OFF" : "SOUND ON"}</span>
              </button>
            </div>

            {/* Slider controls for saturation and brightness */}
            <div id="video-filters" className="flex flex-col sm:flex-row items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[9px] text-muted-foreground/80 min-w-[54px] text-right">SAT: {saturation}%</span>
                <input
                  id="slider-saturation"
                  type="range"
                  min="0"
                  max="200"
                  value={saturation}
                  onChange={(e) => setSaturation(Number(e.target.value))}
                  className="w-16 h-0.5 bg-white/20 hover:bg-white/30 rounded-lg appearance-none cursor-pointer accent-white transition-all outline-none"
                  style={{ WebkitAppearance: 'none' }}
                  title="Adjust background video saturation"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-[9px] text-muted-foreground/80 min-w-[54px] text-right">LUM: {brightness}%</span>
                <input
                  id="slider-brightness"
                  type="range"
                  min="20"
                  max="200"
                  value={brightness}
                  onChange={(e) => setBrightness(Number(e.target.value))}
                  className="w-16 h-0.5 bg-white/20 hover:bg-white/30 rounded-lg appearance-none cursor-pointer accent-white transition-all outline-none"
                  style={{ WebkitAppearance: 'none' }}
                  title="Adjust background video brightness"
                />
              </div>
            </div>
          </div>

          <span>© VELORAH STUDIO</span>
        </div>
      </footer>

      {/* Ambient Elegant Toast Box */}
      {showToast && (
        <div 
          id="toast-notification"
          className="fixed bottom-24 right-8 z-50 liquid-glass rounded-xl px-5 py-3 text-sm text-foreground flex items-center gap-2.5 shadow-2xl border border-white/10 max-w-sm transition-all duration-300 animate-fade-rise"
        >
          <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          <span className="font-light tracking-wide">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
